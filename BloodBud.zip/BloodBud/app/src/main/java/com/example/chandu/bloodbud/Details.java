package com.example.chandu.bloodbud;

import android.content.Intent;
import android.graphics.ColorSpace;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class Details extends AppCompatActivity {
  //  TextView text;
  //  EditText bloodgroup;
    Spinner spBloodgroup;
    Button search;
    String bloodgroup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
      //-  Spinner spinner = findViewById(R.id.spinner );
        //ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(Details.this, R.)

       // text =(TextView)findViewById(R.id.textView);
      //  bloodgroup=(EditText)findViewById(R.id.editText3);
        spBloodgroup = (Spinner) findViewById(R.id.spBgroup);
        search=(Button)findViewById(R.id.button3);
        ArrayAdapter<String> myAdapter = new ArrayAdapter<String>(Details.this,android.R.layout.simple_list_item_1,getResources().getStringArray(R.array.BloodGroup));
        myAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spBloodgroup.setAdapter(myAdapter);
     //   bloodgroup = spBloodgroup.getSelectedItem().toString();

        search.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                bloodgroup = spBloodgroup.getSelectedItem().toString();
                Intent in = new Intent(Details.this, Show.class);
                in.putExtra("bloodgroup", bloodgroup);
                startActivity(in);
            }
        });
    }
}
