package com.example.chandu.bloodbud;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class Show extends AppCompatActivity {
    TextView info;
    FirebaseDatabase fd = FirebaseDatabase.getInstance();
    DatabaseReference dr = fd.getReference();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show);
        String x=getIntent().getExtras().getString("bloodgroup");
        Toast.makeText(getApplicationContext(), x, Toast.LENGTH_SHORT ).show();
        info=(TextView)findViewById(R.id.info);
        dr.child(x).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                int h=0;
                for(DataSnapshot templateSnapshot : dataSnapshot.getChildren()){
                    for(DataSnapshot snap : templateSnapshot.getChildren()){
                        String model = (String) snap.getValue();
                        //info.setText(model+"\n");
                      String str[]= model.split(" ");
                      info.append(model+"\n");
                      h++;
                       if(h==3) {
                           info.append("\n");
                           h=0;
                       }

                        System.out.println(str[0]+"&&&&&&&&&&&&&&&&&&&&******************");

                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

}
