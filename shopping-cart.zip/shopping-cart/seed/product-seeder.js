var Product = require('../models/product');

var mongoose = require('mongoose');

mongoose.connect('mongodb://localhost:27017/shopping',{ useNewUrlParser: true});

var products = [
    new Product({
        imagePath:'https://www.thecrazyprogrammer.com/wp-content/uploads/2015/04/Programming-in-ANSI-C.jpg',
        title: 'Programming-in-ANSI-C',
        description: 'This seventh edition is thoroughly updated with outcome based learning approach as per standard Bloom’s Taxonomy.',
        price:473.00
    }),
    new Product({
        imagePath:'https://img1.cgtrader.com/items/749080/084be81e66/large/beatspeel-bluetooth-speaker-3d-model-obj-3ds-fbx-c4d-stl-mtl.png',
        title: 'Beatspeel Bluetooth speaker 3D model',
        description: 'This model can be use any VFX, Interior, Architecture, 3D Print, Motion Graphics projects.',
        price:4000.00
    }),
    new Product({
        imagePath:'https://images-na.ssl-images-amazon.com/images/I/519TvLjRUdL._SX382_BO1,204,203,200_.jpg',
        title: 'The Oxford English Grammar',
        description: 'The Oxford English Grammar is a book with authentic discourses about English language and grammar, by Prof. Sidney Greenbaum.',
        price:374.00
    }),
    new Product({
        imagePath:'https://images-na.ssl-images-amazon.com/images/I/913t%2BwVT6fL.jpg',
        title: 'Core Java: An Integrated Approach',
        description: 'The book is written in such a way that learners without any background in programming are able to follow and understand it entirely.',
        price:443.00
    }),
    new Product({
        imagePath:'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRqYTSu6AvjcqYNm4AwLBAAHbd7BY50GuqIkDZBRS-NLiP3s8YS',
        title: 'Sarah Round Indian Oxidised Metal Drop Earring',
        description: 'For Women, Girls Contemporary Collection',
        price:575.00
    }),
    new Product({
        imagePath:'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxANDxAPDw8PEA8QDxAQDw0QDQ8PDw8PFREWFhURFRUYHSgiGBonGxcWITEhJSkrLi4uGCAzODMsNygtLisBCgoKDQ0NDw8NDysaFRkrKy0rKy03KysrKysrNysrKysrKystKysrKysrLSsrKysrKysrKysrKysrKysrKysrK//AABEIAOEA4QMBIgACEQEDEQH/xAAcAAEAAQUBAQAAAAAAAAAAAAAAAQIDBgcIBAX/xABBEAACAgEBBAgDBQQHCQAAAAAAAQIDEQQFEiExBgcTIkFRcYEyYZEUI1KhsRWissFUYnKCksLwCBckM0JklNLx/8QAFgEBAQEAAAAAAAAAAAAAAAAAAAEC/8QAFhEBAQEAAAAAAAAAAAAAAAAAAAER/9oADAMBAAIRAxEAPwDeIAAAAAAAAAAFq++FUXOycYRXOUpKMV6tl01T1z0uV2hzNwrlG6M295wTzFptL0YH2NtdaWi0+9GlWaiSyk44jBv1fgY/oes7W22LNWlSsf3NUu0XaPOHFWJtJ+qMJp2BZK2ym147OGYy38qSk+7uPxzxPbp1XartJdCLsrnKrTqCUIRblxa8nlZcv5irjYuk6yn2k6btFPtYPvKq+uSSxneW/u5WC/DrY2U/isug84alRPg+Pj5cDVWp2NqsOztlZuRjFWTm4T3cSSxJ84rDRjut0s3BNVzaT+Jwbj+F5fFc01j5AxvHVdbWz4V9pCGqsjvbm8qHCG/jO7vS4ZxxPhbZ64rK59nTolF8M2XXJqGcPOIc/qYBotNdPT/YaqbN+W7qbFY5Vqvde7vRUviT3kvoTs3Q10XW1amPaTVf3UlyU3jGIvg3xbz4YBjNdm9ZG1F95fDSTj8To3XTY4PlKLcnw/1wMr2L1m6S9wjqIvTOfCNkpKVLn+FyXwv1NaV7OlFqzUKGoshdGbulPcxBJpxTfNJrK8M45Hi2xCOuhVOLdUcvtp7jxiKSc7Nzut5WPLiB0fp9RC2O9XOE4vlKElKL90XTDuqbS9lsjTedm/Y/ebX6IzEIAAAAAAAAAAAAAAAAAAAAAAAAGvOuLRRup0e9Ps4rU7srM4xGUGsZ9cGwzUvX1rnuaTTLlKU7pP8As4il+9n2Awnb2pfbdrVbFUp1VUzVi+CMPi81FPJ5YXQhTKUboyvuaUlGzvQhvpvLxnefHx5GNyLbl/ryNYus9s2279P2O5Gy2f3Tm292MEkoteOW8vmv0x9baWnnGP2PRVxnGVKhf33J1Sbfi3lJ5k/E1rodoWUSU63hxeYvniXmZZb0zqdUJUwnRqlJOy3EZxnF53lnPFZaeGvD5GbDXr6T6qyi5VqcW6dNTXOXHG9vRlxfzaSx4rJ8yFF3/Ea23ejNRsrg3GCc7bKpLu8OGI8eHPPrm3r+lylp1TCveudqnbqrOPaqLe7Fry5c+HDl4mParal9y3bLZyjvb27nu73njzEhr71PSFxolTbCN0t3s697jmMm95zb5s+tqs1aevS6WUIWy0zepj3mnBwzlb2e9x/MwBHphqrEmlZNJ4z3n4Fw11B0Ip7PZmhiv6JRL3lBS/mfcPg9BNT2uy9BP/taY/4IqH+U+8RAAAAAAAAAAAAAAAAAAAQCQBAJAEGqevLR7y0tuH3VZHPq4v8AkbXMW6yNmLU7Pu4ZnUu0j58Of5foWDmyxYPPI9l64s8zRRbQwV4GAKCGXMDAFtF2BGD0bPolbbCuCzKclGK85N4S+rLB0d1WxlHZGkU/CM93z3O0ljJlZ5tmaNaaiqmPw1VwrXz3YpZPUYEAkAQCQAQAAAAAAAAAAAAAAAAAAFrVUK2E63ynCUH6SWC6AOTdu6Z6e+2t84WTi15OMmn+aPm75m/W3oOw2nfhcLGrl899Jv8Ae3jB0jQqyMkEgMlLkVYI3QI3jNOqPZ32natGVmNW9fL5bnw/vOJhTibh6gNn8dXqWuShTF/vS/kBuUAGQAAAAAAAAAAAAAAAAAAAAAAAAAAGl+vfS4v01uOM6ZRb/syz/mNStG3OvbVJ3aapPLhVOcl5b0kl/CzUzRoUYGCogCASMBFLOhOpTTKvZSljjZdY37cEc+HRvU+1+yKMfjsT/tbwqs1ABkAAAAAAAAAAAAAAAAAABBIAEEgACJSSTbeEllvyXmSYV1q7f+w6CcIyxdqc1Qw+Ki/jl9OHuBpnpntl6/Xai/PdlY41Lyqh3Yfks+7Meki7N8C0aFDRS16lTYYRTgEkAEjcfUVtpYv0Mnx/51XHw5TivyfuadPqdGdsT2fq6dTDOappyj+KHKUfeLaA6sBY0mphdXC2tqVdkYzhJcnFrKZfMqgEgAQSAAAAAAAAAAAAAACAAABIAjJzl1ldIv2jr7HCWaKG6acPg0n3p+7/ACSNu9aHSP8AZ2gnuSxffmqrzjld6fsv1RzqiwLJFKfAobyyZMqIEiBNgSGQgACIiyQN19SXSbtapbPtl36szoy+dbfej7P9TauTk3Ym1bNDqatTS+/VJSS8JLxg/k1w9zqPYW1a9dpqdVS8wugppeMX4wfzTyvYlV7wSCAAAAAAAAAAAAAAAAAAABDeCTButvpH9g0EqoSxfqk6oYfGNeO/P6PHuBqXrI6SftPXTlB5opzVR5OKfGfu1n0wYpOXAIt2PLNBHmSxHkQECJhCXMCogAClPi15lSZRN4cX7FQEyNq9SHSfsrZbPtl3Lc2UZfCNiXeivVcfY1Uy7oNXOiyFtct2dc1OEvKUXlAdeJknyujG2IbR0dGqhythmUfwWLhOD9JJo+qZUAAAAAAAAAAAAAAAAAAEN49FzZzV1kdIf2ltCycXmmp9lT5bsXhy93k3H1rdIf2fs+ahLF+p+5qw8NJ/HNekcr1aOc//AIWA3wyWeZXZLwKY+ZUVNlIkyEBKfEJ8WRDmRDxAuEMEMCm34X8uK9iU8pMFGnfd9OAF3JRnj68SWU2Pgn5P8gNw9RG38Su0E3wl99Sn+JJKcV7YfsblRyd0b2rLQ6ujUx51WRk15x5SX0ydWaW+NsIWQacJwjOLXJxkspkqrwAIAAAAAAAAAAAAAAQwfD6a7bjs7QX6ltb0YONS/FdLhBfXj6JgaR63Nvfbdoyrg81ab7mOOTknmb+vD2ML5eyKXY5ycpNttttvm23lsi54RRajxZXN4LdRMmVBFRSmGwKo+JTB8/UlcimHIC5kEIAQU085L5/qVMozifqgLjKWspoqkUrmBNMspHRPUztn7VsyNUnmekm6X59n8Vb9MPd/uHOdTw2vmbN6j9r9hr56eT7upraSzw7SHGPvhtCjfYAMqkAAAAAAAAAAAABDNG9fG3u01FWihLuULtLEvG2Sws+kf4mbs1+qjRVZbN4hXCU5N8korJyVtzaU9bqbtRNvetslPj4JvgvZYRYPNUi3fMuxeIs80uLx5vBRdq4LPmRJlUuHAtyYEiTIREgi8uXsUQfAqfIohyAryTkoKgDLOoeHF+xdLeqWY58mBdb4FLKKpZRWwKLXiSfmj6uw9oy0mop1EPiqsjNLzw+K+mT5Op5J+TLlEuAHYGzNZHU01XweYW1xsi/lJZPSa36jtt/aNBZppvM9Jbux48ewsW9D899eiRsgyoAAAAAAAAAAAAAwDrr2w9Lsx1ReJ6uxU+laTlN/RY/vHOrR1f0q6Maba1Kp1MW91uVdkXuzrk1htP8AkzTPTTqpt2dVPVU6iF2nqTlZGxdndCC8VjhP8nx5Mo1zZwSRaojlt+XL1ZVcya1iPzeWVCRbZXItsCURHmgTWuIF18i3XyLj5FusCSpFLJAEWLMWvkSyYgebTyL7PLTweD0gLVmD+pRppF5Lg/Q82nCtjdTG1XptrQr4uGqqlTJJZ4x70Zez/iOikaQ/2f5L7TrIuKb7CqUZNJyjuzknh+Gd78kbvRKJABAAAAAAAAAADAg1t17691bOqpi2vtGpipfOEISnj/Eo/Q2SePamy6NZX2epprur57s4ppPzXkByBJZePPCL014eXA3T1j9ANmaHQ362qudVtfZquMbJOtznZGCTj5d40vNFFqRQy5IoaKiCuopwVwWEBVLkWoF2XItRAqYQYCpZMSCUB5JrEn6l+LI1NTbyk354WcCoC9Az3YnU7r9VXVqFqNFGq6EbK32l05bkllNrcS5Y8TA4o6b6rb3ZsbQt+FTrXpXZKC9sRRB5erzoDDYvaTlc777YxhKahuQjBPO7GOX4+LfgjNACCUAgAAAAAAAAAAAEABIDybU2dVq6Z0XwVlVixKEuT45T+Tzxz8jXO0upbSWNujU3VZ5Qko2RXu+JtEAaX/3HT/p8P/Hf/sX6Oo2HDtNdP57lMV+uTcIGjV1HUloY/HqdTP5fdx/RGm+kGlro1eoqoz2NV1lde88ycIy3U2/Y61ZqLVdS3aWzn9ue7OcpYdPeWW3zyUaXmidNpp2zjXXCVlk2lCuEXOcn5KK4s31s3qZ0FbTvtvv/AKuY1x/d5mb7G6P6TQR3dLp6qcrDlGK35es3xf1GjQ+j6o9q21do4UVPGVTbc1Y/Xdi0vqfI2n0B2rpc9pob5RX/AF0xV6fzxW28eqR1EiRo45tg65OE04TXOE04SXs+JCidgarSV3Ldtrrsj+GyEZr6M+Hquguy7XmWg0+f6kOz/gwNGruoTP2zVRxmD08d/hlcJvGfzNyanYuktz2ml088/iorb+uBsnY+m0UOz0tFdMW+KhHG8/Nvm/c+gQY1Z0D2VKW89BRn5RkvyTPv6aiFUI11xjCEEoxhFKMYpeCXgXgBBIAAAAAAAAAAAACGSAAAAgIACQAAAAAhkgCGSgAAAAgAASAAIZIAAAAAAAAAH//Z',
        title: 'Sleeveless Lace A Line Party Swing Skater Dress - Black',
        description: 'Material: Cotton, Silhouette: A-Line, Dresses Length: Knee-Length, Neck-line: Round Collar, Sleeves Length: Sleeveless ',
        price:4543.00
    }),
    new Product({
        imagePath:'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQX8kNOhSRcvU9_xqVczFfS2CUxCgsW3EF8x2OvnG6ZgHqysQigVA',
        title: 'BLACK MARIA OFFICE LAPTOP TOTE BAG',
        description: 'Black finish with gold tone hardware, Double zip opens two separate compartments, Front and back compartment fits 13"" laptop.',
        price:1443.00
    })
];
var done = 0;
for(var i=0;i<products.length;i++){
    products[i].save(function(err, result){
        done++;
        if(done === products.length){
            exit();
        }
    });
}

function exit(){
    mongoose.disconnect();
}

